// Language-independent parts of the content; texts live in src/i18n/<lang>.js
export const SERVICES = [
  {icon:'🌐', type:'website'},
  {icon:'⚙️', type:'webapp'},
  {icon:'📱', type:'mobile'},
  {icon:'🛒', type:'ecommerce'},
  {icon:'🚀', type:'landing'},
  {icon:'✨', type:'custom'},
];
